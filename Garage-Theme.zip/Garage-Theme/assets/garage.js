/**
 * Shopify Garage Feature
 * Integrated with Render.com Backend API
 * Updated: 2026-01-22
 */

class ShopifyGarage {
  constructor() {
    // API Configuration
    this.API_BASE = 'https://garage-wl13.onrender.com';
    this.VEHICLES_API = `${this.API_BASE}/apps/vehicles/list`;
    this.GET_GARAGE_API = `${this.API_BASE}/apps/customer/vehicles/get`;
    this.SAVE_GARAGE_API = `${this.API_BASE}/apps/customer/vehicles/save`;

    // Customer data
    this.customerId = window.ShopifyGarage?.customerId;
    this.customerGid = this.customerId ? `gid://shopify/Customer/${this.customerId}` : null;

    // Current garage vehicles (passed from Liquid)
    this.vehicles = window.ShopifyGarage?.vehicles || [];

    // Selected vehicle IDs for filtering
    this.selectedVehicleIds = this.loadSelectedVehicles();

    // All available vehicles (loaded from API)
    this.allVehicles = [];
    this.vehiclesLoaded = false;

    // Organized by type for selector
    this.vehiclesByType = { Car: [], Truck: [] };

    // Vehicle selector state
    this.selectorState = {
      type: null,
      year: null,
      make: null,
      model: null,
      selectedVehicle: null
    };

    // Cache keys
    this.VEHICLES_CACHE_KEY = 'garage_vehicles_cache';
    this.VEHICLES_CACHE_TIME_KEY = 'garage_vehicles_cache_time';
    this.CACHE_DURATION = 1000 * 60 * 60; // 1 hour

    this.init();
  }

  async init() {
    await this.loadAllVehicles();
    this.bindEvents();
    this.initializeFilterState();
    this.updateUI();
  }

  // ============================================
  // Load All Vehicles from Render API
  // ============================================

  async loadAllVehicles() {
    console.log('Loading vehicles from Render API...');

    // Check cache first
    const cachedData = localStorage.getItem(this.VEHICLES_CACHE_KEY);
    const cachedTime = localStorage.getItem(this.VEHICLES_CACHE_TIME_KEY);

    if (cachedData && cachedTime) {
      const age = Date.now() - parseInt(cachedTime);
      if (age < this.CACHE_DURATION) {
        console.log('Using cached vehicle data');
        this.allVehicles = JSON.parse(cachedData);
        this.organizeVehicles();
        this.vehiclesLoaded = true;
        return;
      }
    }

    // Fetch from API
    try {
      const response = await fetch(this.VEHICLES_API);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();

      if (!data.success || !data.vehicles) {
        throw new Error(data.error || 'Invalid API response');
      }

      this.allVehicles = data.vehicles;
      this.organizeVehicles();
      this.vehiclesLoaded = true;

      // Cache the data
      localStorage.setItem(this.VEHICLES_CACHE_KEY, JSON.stringify(this.allVehicles));
      localStorage.setItem(this.VEHICLES_CACHE_TIME_KEY, Date.now().toString());

      console.log(`Loaded ${this.allVehicles.length} vehicles from API`);

    } catch (error) {
      console.error('Error loading vehicles:', error);
      this.showError('Failed to load vehicle database. Please refresh the page.');
    }
  }

  organizeVehicles() {
    this.vehiclesByType = {
      Car: this.allVehicles.filter(v => v.type === 'Car'),
      Truck: this.allVehicles.filter(v => v.type === 'Truck')
    };
  }

  // ============================================
  // Selection Management
  // ============================================

  loadSelectedVehicles() {
    const stored = localStorage.getItem('garage_selected_vehicles');
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch(e) {
        return [];
      }
    }
    // Default: select all vehicles in garage
    return this.vehicles.map(v => v.vehicleId || v.vehicle_id?.value);
  }

  saveSelectedVehicles() {
    localStorage.setItem('garage_selected_vehicles', JSON.stringify(this.selectedVehicleIds));
    document.dispatchEvent(new CustomEvent('garage:selection-changed', {
      detail: {
        vehicleIds: this.selectedVehicleIds,
        vehicles: this.getSelectedVehicles()
      }
    }));
  }

  getSelectedVehicles() {
    return this.vehicles.filter(v => {
      const vehicleId = v.vehicleId || v.vehicle_id?.value;
      return this.selectedVehicleIds.includes(vehicleId);
    });
  }

  toggleVehicleSelection(vehicleId) {
    const index = this.selectedVehicleIds.indexOf(vehicleId);
    if (index > -1) {
      this.selectedVehicleIds.splice(index, 1);
    } else {
      this.selectedVehicleIds.push(vehicleId);
    }
    this.saveSelectedVehicles();
    this.updateUI();
  }

  // ============================================
  // Event Binding
  // ============================================

  bindEvents() {
    // Add vehicle button
    document.querySelectorAll('[data-garage-add-vehicle]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openModal();
      });
    });

    // Remove vehicle buttons
    document.querySelectorAll('[data-garage-remove-vehicle]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const vehicleGid = e.currentTarget.dataset.garageRemoveVehicle;
        this.removeVehicle(vehicleGid);
      });
    });

    // Selection checkboxes
    document.querySelectorAll('[data-garage-select-vehicle], [data-quick-select-vehicle], [data-vehicle-filter], [data-filter-vehicle]').forEach(checkbox => {
      checkbox.addEventListener('change', (e) => {
        const vehicleId = e.currentTarget.dataset.garageSelectVehicle ||
                          e.currentTarget.dataset.quickSelectVehicle ||
                          e.currentTarget.dataset.vehicleFilter ||
                          e.currentTarget.dataset.filterVehicle;
        this.toggleVehicleSelection(vehicleId);
      });
    });

    // Modal controls
    document.querySelectorAll('[data-garage-modal-close]').forEach(el => {
      el.addEventListener('click', () => this.closeModal());
    });

    // Vehicle type selection
    document.querySelectorAll('[data-select-type]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.selectType(e.currentTarget.dataset.selectType);
      });
    });

    // Back buttons
    document.querySelectorAll('[data-selector-back]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.goBackToStep(e.currentTarget.dataset.selectorBack);
      });
    });

    // Search inputs
    document.querySelectorAll('[data-selector-search]').forEach(input => {
      input.addEventListener('input', (e) => {
        this.filterOptions(e.target.dataset.selectorSearch, e.target.value);
      });
    });

    // Confirm add button
    const confirmBtn = document.querySelector('[data-confirm-add-vehicle]');
    if (confirmBtn) {
      confirmBtn.addEventListener('click', () => this.confirmAddVehicle());
    }

    // Header popup toggle
    const popupTrigger = document.querySelector('[data-garage-popup-trigger]');
    const popup = document.querySelector('[data-garage-popup]');
    const popupClose = document.querySelector('[data-garage-popup-close]');

    if (popupTrigger && popup) {
      popupTrigger.addEventListener('click', (e) => {
        e.stopPropagation();
        popup.classList.toggle('is-open');
      });

      if (popupClose) {
        popupClose.addEventListener('click', () => {
          popup.classList.remove('is-open');
        });
      }

      document.addEventListener('click', (e) => {
        if (!popup.contains(e.target) && !popupTrigger.contains(e.target)) {
          popup.classList.remove('is-open');
        }
      });
    }
  }

  // ============================================
  // Modal & Step Navigation
  // ============================================

  openModal() {
    if (!this.vehiclesLoaded) {
      alert('Vehicle database is still loading. Please wait a moment and try again.');
      return;
    }

    const modal = document.querySelector('[data-garage-modal]');
    if (!modal) return;

    // Reset state
    this.selectorState = {
      type: null,
      year: null,
      make: null,
      model: null,
      selectedVehicle: null
    };

    // Show first step, hide others
    this.showStep('type');
    this.updateBreadcrumb();

    modal.hidden = false;
    document.body.classList.add('modal-open');

    // Close header popup if open
    const popup = document.querySelector('[data-garage-popup]');
    if (popup) popup.classList.remove('is-open');
  }

  closeModal() {
    const modal = document.querySelector('[data-garage-modal]');
    if (modal) {
      modal.hidden = true;
      document.body.classList.remove('modal-open');
    }
  }

  showStep(step) {
    document.querySelectorAll('[data-selector-step]').forEach(el => {
      el.hidden = el.dataset.selectorStep !== step;
    });

    // Focus search input if available
    const searchInput = document.querySelector(`[data-selector-step="${step}"] [data-selector-search]`);
    if (searchInput) {
      searchInput.value = '';
      setTimeout(() => searchInput.focus(), 100);
    }
  }

  goBackToStep(step) {
    // Clear subsequent selections
    const steps = ['type', 'year', 'make', 'model', 'confirm'];
    const stepIndex = steps.indexOf(step);

    steps.slice(stepIndex + 1).forEach(s => {
      this.selectorState[s] = null;
    });
    this.selectorState.selectedVehicle = null;

    this.showStep(step);
    this.updateBreadcrumb();
  }

  updateBreadcrumb() {
    const breadcrumb = document.querySelector('[data-selector-breadcrumb]');
    if (!breadcrumb) return;

    const { type, year, make, model } = this.selectorState;

    breadcrumb.hidden = !type;

    const typeEl = breadcrumb.querySelector('[data-breadcrumb-type]');
    const yearEl = breadcrumb.querySelector('[data-breadcrumb-year]');
    const makeEl = breadcrumb.querySelector('[data-breadcrumb-make]');
    const modelEl = breadcrumb.querySelector('[data-breadcrumb-model]');

    if (typeEl) typeEl.textContent = type || '';
    if (yearEl) yearEl.textContent = year ? ` › ${year}` : '';
    if (makeEl) makeEl.textContent = make ? ` › ${make}` : '';
    if (modelEl) modelEl.textContent = model ? ` › ${model}` : '';
  }

  // ============================================
  // Vehicle Selection Steps (Client-Side Filtering)
  // ============================================

  selectType(type) {
    this.selectorState.type = type;
    this.updateBreadcrumb();

    // Highlight selected
    document.querySelectorAll('[data-select-type]').forEach(btn => {
      btn.classList.toggle('is-selected', btn.dataset.selectType === type);
    });

    // Load years for this type
    this.loadYears(type);
    this.showStep('year');
  }

  loadYears(type) {
    const container = document.querySelector('[data-selector-options="year"]');
    if (!container) return;

    const typeVehicles = this.vehiclesByType[type] || [];

    if (typeVehicles.length === 0) {
      container.innerHTML = '<div class="selector-empty">No vehicles found for this type.</div>';
      return;
    }

    // Get unique years, sort descending (newest first)
    const years = [...new Set(typeVehicles.map(v => v.year))].filter(y => y).sort((a, b) => b - a);

    container.innerHTML = years.map(year => `
      <button type="button" class="selector-option" data-select-year="${year}">
        ${year}
      </button>
    `).join('');

    // Bind click events
    container.querySelectorAll('[data-select-year]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.selectYear(parseInt(e.currentTarget.dataset.selectYear));
      });
    });
  }

  selectYear(year) {
    this.selectorState.year = year;
    this.updateBreadcrumb();

    this.loadMakes(this.selectorState.type, year);
    this.showStep('make');
  }

  loadMakes(type, year) {
    const container = document.querySelector('[data-selector-options="make"]');
    if (!container) return;

    const typeVehicles = this.vehiclesByType[type] || [];
    const makes = [...new Set(
      typeVehicles
        .filter(v => v.year === year)
        .map(v => v.make)
    )].filter(m => m).sort();

    if (makes.length === 0) {
      container.innerHTML = '<div class="selector-empty">No makes found.</div>';
      return;
    }

    container.innerHTML = makes.map(make => `
      <button type="button" class="selector-option" data-select-make="${make}">
        ${make}
      </button>
    `).join('');

    container.querySelectorAll('[data-select-make]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.selectMake(e.currentTarget.dataset.selectMake);
      });
    });
  }

  selectMake(make) {
    this.selectorState.make = make;
    this.updateBreadcrumb();

    this.loadModels(this.selectorState.type, this.selectorState.year, make);
    this.showStep('model');
  }

  loadModels(type, year, make) {
    const container = document.querySelector('[data-selector-options="model"]');
    if (!container) return;

    const typeVehicles = this.vehiclesByType[type] || [];
    const vehicles = typeVehicles.filter(v =>
      v.year === year && v.make === make
    );

    if (vehicles.length === 0) {
      container.innerHTML = '<div class="selector-empty">No models found.</div>';
      return;
    }

    // Sort by model name
    vehicles.sort((a, b) => a.model.localeCompare(b.model));

    container.innerHTML = vehicles.map(v => `
      <button type="button" class="selector-option" data-select-model="${v.model}" data-vehicle-gid="${v.gid}">
        <span class="model-name">${v.model}</span>
        ${v.name ? `<span class="model-full-name">${v.name}</span>` : ''}
      </button>
    `).join('');

    container.querySelectorAll('[data-select-model]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const gid = e.currentTarget.dataset.vehicleGid;
        const vehicle = this.allVehicles.find(v => v.gid === gid);
        if (vehicle) {
          this.selectModel(vehicle);
        }
      });
    });
  }

  selectModel(vehicle) {
    this.selectorState.model = vehicle.model;
    this.selectorState.selectedVehicle = vehicle;
    this.updateBreadcrumb();

    // Update preview
    const typeEl = document.querySelector('[data-preview-type]');
    const nameEl = document.querySelector('[data-preview-name]');
    const detailsEl = document.querySelector('[data-preview-details]');

    if (typeEl) {
      typeEl.textContent = vehicle.type;
      typeEl.className = `vehicle-type-badge vehicle-type--${vehicle.type.toLowerCase()}`;
    }
    if (nameEl) {
      nameEl.textContent = vehicle.name || `${vehicle.year} ${vehicle.make} ${vehicle.model}`;
    }
    if (detailsEl) {
      detailsEl.textContent = `${vehicle.year} · ${vehicle.make} · ${vehicle.model}`;
    }

    this.showStep('confirm');
  }

  // ============================================
  // Search/Filter Options
  // ============================================

  filterOptions(field, searchTerm) {
    const container = document.querySelector(`[data-selector-options="${field}"]`);
    if (!container) return;

    const options = container.querySelectorAll('.selector-option');
    const term = searchTerm.toLowerCase().trim();

    options.forEach(option => {
      const text = option.textContent.toLowerCase();
      option.style.display = term === '' || text.includes(term) ? '' : 'none';
    });
  }

  // ============================================
  // Add/Remove Vehicle (Render API)
  // ============================================

  async confirmAddVehicle() {
    const vehicle = this.selectorState.selectedVehicle;
    if (!vehicle) return;

    // Check if already in garage
    if (this.vehicles.some(v => (v.gid || v.id) === vehicle.gid)) {
      alert('This vehicle is already in your garage.');
      this.closeModal();
      return;
    }

    const confirmBtn = document.querySelector('[data-confirm-add-vehicle]');
    if (confirmBtn) {
      confirmBtn.disabled = true;
      confirmBtn.textContent = 'Adding...';
    }

    try {
      await this.addVehicleToGarage(vehicle.gid);

      this.closeModal();
      this.showSuccess('Vehicle added! Refreshing...');
      setTimeout(() => window.location.reload(), 1000);

    } catch (error) {
      console.error('Error adding vehicle:', error);
      this.showError('Failed to add vehicle: ' + error.message);

      if (confirmBtn) {
        confirmBtn.disabled = false;
        confirmBtn.textContent = 'Add to My Garage';
      }
    }
  }

  async removeVehicle(vehicleGid) {
    if (!confirm('Remove this vehicle from your garage?')) return;

    try {
      this.showLoading('Removing vehicle...');
      await this.removeVehicleFromGarage(vehicleGid);

      // Remove from selected filters
      const vehicleId = this.vehicles.find(v => (v.gid || v.id) === vehicleGid)?.vehicleId;
      if (vehicleId) {
        this.selectedVehicleIds = this.selectedVehicleIds.filter(id => id !== vehicleId);
        this.saveSelectedVehicles();
      }

      this.showSuccess('Vehicle removed! Refreshing...');
      setTimeout(() => window.location.reload(), 1000);

    } catch (error) {
      console.error('Error removing vehicle:', error);
      this.showError('Failed to remove vehicle: ' + error.message);
    }
  }

  // ============================================
  // Backend API Calls
  // ============================================

  async addVehicleToGarage(vehicleGid) {
    if (!this.customerId) {
      throw new Error('Must be logged in to add vehicles');
    }

    // Get current garage GIDs
    const currentGids = this.vehicles.map(v => v.gid || v.id);
    const newGids = [...currentGids, vehicleGid];

    return this.updateGarageMetafield(newGids);
  }

  async removeVehicleFromGarage(vehicleGid) {
    if (!this.customerId) {
      throw new Error('Must be logged in to remove vehicles');
    }

    const newGids = this.vehicles
      .filter(v => (v.gid || v.id) !== vehicleGid)
      .map(v => v.gid || v.id);

    return this.updateGarageMetafield(newGids);
  }

  async updateGarageMetafield(vehicleGids) {
    const response = await fetch(this.SAVE_GARAGE_API, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        customerId: this.customerGid,
        vehicles: vehicleGids
      })
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || `HTTP ${response.status}: ${response.statusText}`);
    }

    return response.json();
  }

  // ============================================
  // UI Updates
  // ============================================

  updateUI() {
    const selectedVehicles = this.getSelectedVehicles();

    // Update quick selector label
    const quickLabel = document.querySelector('[data-garage-quick-label]');
    if (quickLabel) {
      if (selectedVehicles.length === 0) {
        quickLabel.textContent = 'No Vehicle Selected';
      } else if (selectedVehicles.length === 1) {
        const v = selectedVehicles[0];
        const year = v.year?.value || v.year;
        const make = v.make?.value || v.make;
        const model = v.model?.value || v.model;
        quickLabel.textContent = `${year} ${make} ${model}`;
      } else {
        quickLabel.textContent = `${selectedVehicles.length} Vehicles`;
      }
    }

    // Update card selected states
    document.querySelectorAll('[data-vehicle-id]').forEach(card => {
      const vehicleId = card.dataset.vehicleId;
      card.classList.toggle('is-selected', this.selectedVehicleIds.includes(vehicleId));
    });

    // Sync all checkboxes
    document.querySelectorAll('[data-garage-select-vehicle], [data-quick-select-vehicle], [data-vehicle-filter], [data-filter-vehicle]').forEach(checkbox => {
      const vehicleId = checkbox.dataset.garageSelectVehicle ||
                        checkbox.dataset.quickSelectVehicle ||
                        checkbox.dataset.vehicleFilter ||
                        checkbox.dataset.filterVehicle;
      checkbox.checked = this.selectedVehicleIds.includes(vehicleId);
    });
  }

  initializeFilterState() {
    document.querySelectorAll('[data-vehicle-filter], [data-garage-select-vehicle], [data-quick-select-vehicle], [data-filter-vehicle]').forEach(checkbox => {
      const vehicleId = checkbox.dataset.vehicleFilter ||
                        checkbox.dataset.garageSelectVehicle ||
                        checkbox.dataset.quickSelectVehicle ||
                        checkbox.dataset.filterVehicle;
      checkbox.checked = this.selectedVehicleIds.includes(vehicleId);
    });
  }

  // ============================================
  // Status Messages
  // ============================================

  showLoading(message) {
    const statusEl = document.getElementById('status-message') || this.createStatusElement();
    statusEl.className = 'status-message show loading';
    statusEl.textContent = message;
  }

  showSuccess(message) {
    const statusEl = document.getElementById('status-message') || this.createStatusElement();
    statusEl.className = 'status-message show success';
    statusEl.textContent = message;
  }

  showError(message) {
    const statusEl = document.getElementById('status-message') || this.createStatusElement();
    statusEl.className = 'status-message show error';
    statusEl.textContent = message;
  }

  createStatusElement() {
    const el = document.createElement('div');
    el.id = 'status-message';
    el.className = 'status-message';
    document.body.insertBefore(el, document.body.firstChild);
    return el;
  }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  if (typeof window.ShopifyGarage !== 'undefined') {
    window.garageInstance = new ShopifyGarage();
  } else {
    console.warn('ShopifyGarage configuration not found. Make sure to include garage-data.liquid snippet.');
  }
});
