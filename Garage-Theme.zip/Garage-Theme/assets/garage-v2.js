/**
 * Shopify Garage Feature - Version 2
 * Auto-save with simplified UI
 * Updated: 2026-01-24
 */

class ShopifyGarageV2 {
  constructor() {
    // API Configuration - Production backend
    this.API_BASE = 'https://garage-wl13.onrender.com';

    // Customer data - Set by Liquid template via window.ShopifyGarage
    this.customerId = window.ShopifyGarage?.customerId;
    this.customerGid = this.customerId ? `gid://shopify/Customer/${this.customerId}` : null;

    // State
    this.allVehicles = [];
    this.myGarage = [];
    this.saveTimeout = null;
    this.isSaving = false;

    // Cache
    this.VEHICLES_CACHE_KEY = 'garage_vehicles_cache_v2';
    this.VEHICLES_CACHE_TIME_KEY = 'garage_vehicles_cache_time_v2';
    this.CACHE_DURATION = 1000 * 60 * 60; // 1 hour

    this.init();
  }

  async init() {
    // Get DOM elements
    this.garageIcon = document.querySelector('[data-garage-icon]');
    this.garageBadge = document.querySelector('[data-garage-badge]');
    this.modalOverlay = document.querySelector('[data-garage-modal-overlay]');
    this.closeModal = document.querySelector('[data-garage-modal-close]');
    this.searchBox = document.querySelector('[data-garage-search]');
    this.vehicleList = document.querySelector('[data-garage-vehicle-list]');
    this.loadingMessage = document.querySelector('[data-garage-loading]');
    this.myGarageTop = document.querySelector('[data-my-garage-top]');
    this.myGarageList = document.querySelector('[data-my-garage-list]');
    this.emptyGarage = document.querySelector('[data-garage-empty]');
    this.garageCount = document.querySelector('[data-garage-count]');
    this.savingIndicator = document.querySelector('[data-garage-saving]');

    if (!this.garageIcon || !this.modalOverlay) {
      console.warn('Garage UI elements not found');
      return;
    }

    // Bind events
    this.garageIcon.addEventListener('click', () => this.openModal());
    this.closeModal?.addEventListener('click', () => this.closeModalFn());
    this.modalOverlay.addEventListener('click', (e) => {
      if (e.target === this.modalOverlay) this.closeModalFn();
    });
    this.searchBox?.addEventListener('input', (e) => this.handleSearch(e.target.value));

    // Load initial data
    await this.loadCustomerGarage();
  }

  // ============================================
  // Load Customer Garage
  // ============================================

  async loadCustomerGarage() {
    if (!this.customerGid) {
      console.log('Customer not logged in');
      this.myGarage = [];
      this.updateBadge();
      return;
    }

    try {
      const response = await fetch(
        `${this.API_BASE}/apps/customer/vehicles/get?customerId=${encodeURIComponent(this.customerGid)}`
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();

      // data.vehicles contains array of GIDs
      this.myGarage = data.vehicles || [];
      this.updateBadge();

      console.log(`Loaded ${this.myGarage.length} vehicles from garage`);
    } catch (error) {
      console.error('Error loading customer garage:', error);
      this.myGarage = [];
      this.updateBadge();
    }
  }

  // ============================================
  // Load All Vehicles
  // ============================================

  async loadAllVehicles() {
    // Check cache first
    const cachedData = localStorage.getItem(this.VEHICLES_CACHE_KEY);
    const cachedTime = localStorage.getItem(this.VEHICLES_CACHE_TIME_KEY);

    if (cachedData && cachedTime) {
      const age = Date.now() - parseInt(cachedTime);
      if (age < this.CACHE_DURATION) {
        console.log('Using cached vehicle data');
        this.allVehicles = JSON.parse(cachedData);
        this.renderVehicleList();
        return;
      }
    }

    // Show loading
    if (this.loadingMessage) this.loadingMessage.style.display = 'block';
    if (this.vehicleList) this.vehicleList.style.display = 'none';

    try {
      const response = await fetch(`${this.API_BASE}/apps/vehicles/list`);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      this.allVehicles = data.vehicles || [];

      // Cache the data
      localStorage.setItem(this.VEHICLES_CACHE_KEY, JSON.stringify(this.allVehicles));
      localStorage.setItem(this.VEHICLES_CACHE_TIME_KEY, Date.now().toString());

      this.renderVehicleList();
      console.log(`Loaded ${this.allVehicles.length} vehicles from API`);
    } catch (error) {
      console.error('Error loading vehicles:', error);
      if (this.loadingMessage) {
        this.loadingMessage.textContent = 'Error loading vehicles. Please try again.';
      }
    }
  }

  // ============================================
  // UI Rendering
  // ============================================

  renderVehicleList(searchTerm = '') {
    if (!this.vehicleList) return;

    const term = searchTerm.toLowerCase().trim();
    let filteredVehicles = this.allVehicles;

    if (term) {
      filteredVehicles = this.allVehicles.filter(v => {
        const searchStr = `${v.year} ${v.make} ${v.model} ${v.style || ''}`.toLowerCase();
        return searchStr.includes(term);
      });
    }

    if (this.loadingMessage) this.loadingMessage.style.display = 'none';
    this.vehicleList.style.display = 'flex';

    if (filteredVehicles.length === 0) {
      this.vehicleList.innerHTML = '<div style="padding: 2rem; text-align: center; color: #999;">No vehicles found</div>';
      return;
    }

    this.vehicleList.innerHTML = filteredVehicles.map(vehicle => {
      const isInGarage = this.myGarage.includes(vehicle.gid);
      return `
        <div class="vehicle-item ${isInGarage ? 'selected' : ''}" data-vehicle-gid="${vehicle.gid}">
          <input
            type="checkbox"
            class="vehicle-checkbox"
            ${isInGarage ? 'checked' : ''}
            data-vehicle-gid="${vehicle.gid}"
          />
          <div class="vehicle-info">
            <div class="vehicle-name">${vehicle.year} ${vehicle.make} ${vehicle.model}</div>
            ${vehicle.style ? `<div class="vehicle-style">${vehicle.style}</div>` : ''}
          </div>
        </div>
      `;
    }).join('');

    // Add event listeners
    this.vehicleList.querySelectorAll('.vehicle-item').forEach(item => {
      const checkbox = item.querySelector('.vehicle-checkbox');
      const vehicleGid = item.dataset.vehicleGid;

      item.addEventListener('click', (e) => {
        if (e.target !== checkbox) {
          checkbox.checked = !checkbox.checked;
          this.toggleVehicle(vehicleGid, checkbox.checked);
        }
      });

      checkbox.addEventListener('change', (e) => {
        e.stopPropagation();
        this.toggleVehicle(vehicleGid, checkbox.checked);
      });
    });
  }

  renderMyGarage() {
    if (!this.myGarageList) return;

    if (this.myGarage.length === 0) {
      if (this.myGarageTop) this.myGarageTop.style.display = 'none';
      if (this.emptyGarage) this.emptyGarage.style.display = 'block';
      if (this.garageCount) this.garageCount.textContent = '0';
      return;
    }

    if (this.myGarageTop) this.myGarageTop.classList.add('active');
    if (this.emptyGarage) this.emptyGarage.style.display = 'none';
    if (this.garageCount) this.garageCount.textContent = this.myGarage.length;

    // Get vehicle details for garage items
    const garageVehicles = this.myGarage
      .map(gid => this.allVehicles.find(v => v.gid === gid))
      .filter(v => v); // Remove any not found

    this.myGarageList.innerHTML = garageVehicles.map(vehicle => `
      <div class="my-garage-chip">
        <span class="vehicle-chip-text">${vehicle.year} ${vehicle.make} ${vehicle.model}</span>
        <button
          class="remove-chip-btn"
          data-remove-vehicle="${vehicle.gid}"
          aria-label="Remove ${vehicle.year} ${vehicle.make} ${vehicle.model}"
        >&times;</button>
      </div>
    `).join('');

    // Add remove event listeners
    this.myGarageList.querySelectorAll('.remove-chip-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const vehicleGid = btn.dataset.removeVehicle;
        this.toggleVehicle(vehicleGid, false);
      });
    });
  }

  handleSearch(searchTerm) {
    this.renderVehicleList(searchTerm);
  }

  updateBadge() {
    if (!this.garageBadge) return;

    const count = this.myGarage.length;
    this.garageBadge.textContent = count;

    if (count > 0) {
      this.garageBadge.classList.add('active');
    } else {
      this.garageBadge.classList.remove('active');
    }
  }

  // ============================================
  // Modal Management
  // ============================================

  async openModal() {
    if (!this.modalOverlay) return;

    // Load vehicles if not already loaded
    if (this.allVehicles.length === 0) {
      await this.loadAllVehicles();
    }

    this.renderMyGarage();
    this.renderVehicleList();

    this.modalOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';

    // Focus search box
    setTimeout(() => this.searchBox?.focus(), 100);
  }

  closeModalFn() {
    if (!this.modalOverlay) return;

    this.modalOverlay.classList.remove('active');
    document.body.style.overflow = '';

    if (this.searchBox) this.searchBox.value = '';
  }

  // ============================================
  // Vehicle Management (Auto-Save)
  // ============================================

  toggleVehicle(vehicleGid, add) {
    if (add) {
      if (!this.myGarage.includes(vehicleGid)) {
        this.myGarage.push(vehicleGid);
      }
    } else {
      this.myGarage = this.myGarage.filter(gid => gid !== vehicleGid);
    }

    this.updateBadge();
    this.renderMyGarage();
    this.scheduleAutoSave();
  }

  scheduleAutoSave() {
    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
    }

    this.showSavingIndicator('Saving...');

    this.saveTimeout = setTimeout(() => {
      this.autoSaveGarage();
    }, 1000); // 1 second debounce
  }

  async autoSaveGarage() {
    if (!this.customerGid) {
      console.warn('Cannot save: customer not logged in');
      return;
    }

    if (this.isSaving) return;

    this.isSaving = true;

    try {
      const response = await fetch(`${this.API_BASE}/apps/customer/vehicles/save`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          customerId: this.customerGid,
          vehicles: this.myGarage
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMsg = errorData.error || errorData.errors?.[0]?.message || `HTTP ${response.status}`;
        console.error('Backend error:', errorData);
        throw new Error(errorMsg);
      }

      const data = await response.json();
      console.log('Garage saved successfully', data);
      this.showSavingIndicator('✓ Saved', 2000);

      // Dispatch event for filter integration
      document.dispatchEvent(new CustomEvent('garage:updated', {
        detail: { vehicles: this.myGarage }
      }));

    } catch (error) {
      console.error('Error saving garage:', error);
      console.error('Customer GID:', this.customerGid);
      console.error('Vehicle GIDs:', this.myGarage);
      this.showSavingIndicator('✗ Save failed - Check console', 5000);
    } finally {
      this.isSaving = false;
    }
  }

  showSavingIndicator(message, hideAfter = null) {
    if (!this.savingIndicator) return;

    this.savingIndicator.textContent = message;
    this.savingIndicator.style.display = 'block';

    if (hideAfter) {
      setTimeout(() => {
        if (this.savingIndicator) {
          this.savingIndicator.style.display = 'none';
        }
      }, hideAfter);
    }
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.shopifyGarageV2 = new ShopifyGarageV2();
  });
} else {
  window.shopifyGarageV2 = new ShopifyGarageV2();
}
