# Upgrade Guide: Garage Feature V1 → V2

This guide helps you upgrade from the old garage implementation to the new auto-save version with modern UI.

## What's New in V2

### ✨ Features
- **Auto-save**: No manual save button needed - changes save automatically after 1 second
- **Cleaner UI**: "My Garage" displayed as chips at the top of modal
- **Better UX**: Simpler, more intuitive interface
- **Blue header design**: Matches the theme we finalized in testing
- **Garage icon with stroke-width 1.25**: The refined icon design

### 🗑️ Removed
- Multi-step vehicle selector (type → year → make → model)
- Manual "Save Garage" button
- Complex filter widgets
- Breadcrumb navigation

### 🎯 Simplified
- Single search box for all vehicles
- Click or checkbox to add/remove
- Visual feedback with chips
- Automatic persistence

## Files Added

### New JavaScript
- `assets/garage-v2.js` - Modern implementation with auto-save

### New Liquid Template
- `snippets/customer-garage-modal-v2.liquid` - Modern modal UI

## Migration Steps

### Option A: Quick Switch (Recommended)

This replaces the old garage with the new one entirely.

#### Step 1: Update theme.liquid

Find where the old garage is included (around line 635):

```liquid
{%- comment -%} Garage Modals {%- endcomment -%}
{%- render 'garage-view-modal' -%}
{%- render 'customer-garage-modal' -%}
```

Replace with:

```liquid
{%- comment -%} Garage Modal V2 {%- endcomment -%}
{%- render 'customer-garage-modal-v2' -%}
```

#### Step 2: Update Script Include

Find where garage.js is loaded (check layout/theme.liquid or snippets):

**Old:**
```liquid
<script src="{{ 'garage.js' | asset_url }}" defer></script>
```

**New:**
```liquid
<script src="{{ 'garage-v2.js' | asset_url }}" defer></script>
```

#### Step 3: Update Garage Icon (Header)

The garage icon/button needs to use the new data attribute.

Find your header garage icon (likely in `sections/header.liquid` or similar).

**Old:**
```liquid
<div data-garage-add-vehicle>
  {%- render 'icon-garage' -%}
</div>
```

**New:**
```liquid
<div data-garage-icon style="position: relative; cursor: pointer;">
  {%- comment -%} Garage Icon {%- endcomment -%}
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round">
    <path d="M3 10L12 3L21 10"/>
    <path d="M4 10V21H20V10"/>
    <line x1="6" y1="13" x2="18" y2="13"/>
    <line x1="6" y1="16" x2="18" y2="16"/>
    <line x1="6" y1="19" x2="18" y2="19"/>
  </svg>

  {%- comment -%} Badge {%- endcomment -%}
  <span class="garage-badge" data-garage-badge>0</span>
</div>
```

Add badge CSS:
```css
.garage-badge {
  position: absolute;
  top: -5px;
  right: -5px;
  background: #e74c3c;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  display: none;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  font-weight: bold;
}

.garage-badge.active {
  display: flex;
}
```

#### Step 4: Update Customer Data Script

Make sure customer ID is available to JavaScript (should already exist from filter integration):

In `layout/theme.liquid` (already done for filter integration):
```liquid
{% if customer %}
  <script>
    window.ShopifyGarage = window.ShopifyGarage || {};
    window.ShopifyGarage.customerId = {{ customer.id | json }};
  </script>
{% endif %}
```

#### Step 5: Test

1. Upload the theme
2. Log in as a customer
3. Click garage icon
4. Add/remove vehicles
5. Verify auto-save works (watch console for "Garage saved successfully")
6. Reload page and confirm vehicles persist

### Option B: Side-by-Side (Testing)

Keep both versions temporarily for testing.

1. Upload new files (`garage-v2.js`, `customer-garage-modal-v2.liquid`)
2. Add a test button somewhere:
   ```liquid
   <button onclick="window.shopifyGarageV2?.openModal()">Test V2 Garage</button>
   ```
3. Include both scripts:
   ```liquid
   <script src="{{ 'garage.js' | asset_url }}" defer></script>
   <script src="{{ 'garage-v2.js' | asset_url }}" defer></script>
   ```
4. Test V2, then switch when ready

## Troubleshooting

### Badge doesn't show count

**Check:**
- `data-garage-badge` attribute exists on badge element
- Customer is logged in
- `window.ShopifyGarage.customerId` is set

### Modal doesn't open

**Check:**
- `data-garage-icon` attribute on clickable element
- `garage-v2.js` is loaded (check browser console)
- No JavaScript errors (check console)

### Vehicles don't save

**Check:**
- Customer is logged in (`window.ShopifyGarage.customerId` exists)
- Backend is running: https://garage-wl13.onrender.com/health
- Network tab shows POST to `/apps/customer/vehicles/save`
- Check for CORS errors

### Search doesn't work

**Check:**
- `data-garage-search` attribute on input
- Vehicles have loaded (check console for "Loaded X vehicles from API")

## Cleanup (After V2 is Working)

Once V2 is tested and working, you can remove old files:

### Files to Remove
- `assets/garage.js` (old version)
- `snippets/customer-garage-modal.liquid` (old modal)
- `snippets/garage-view-modal.liquid` (if unused)
- `snippets/garage-vehicle-selector.liquid` (if unused)
- `snippets/garage-quick-selector.liquid` (if unused)

### Keep These Files
- `assets/garage-v2.js` (new version)
- `assets/garage-filter-integration.js` (filter auto-selection)
- `snippets/customer-garage-modal-v2.liquid` (new modal)
- `snippets/garage-data.liquid` (customer data setup)
- Icon snippets (if used elsewhere)

## Rollback Plan

If V2 has issues, rollback is simple:

1. Revert `layout/theme.liquid` changes
2. Switch script back to `garage.js`
3. Switch modal back to `customer-garage-modal.liquid`
4. Clear browser cache
5. Test old version works

## Features Comparison

| Feature | V1 (Old) | V2 (New) |
|---------|----------|----------|
| Vehicle selection | Multi-step dropdown | Search + click/checkbox |
| Save method | Manual button | Auto-save (1s debounce) |
| My Garage display | Bottom of modal | Top as chips |
| UI complexity | High (multiple screens) | Low (single screen) |
| User experience | 4-5 clicks to add | 1-2 clicks to add |
| Mobile friendly | Moderate | Excellent |
| Icon design | Basic | Garage door (stroke 1.25) |
| Header color | Default | Blue (#1e3a8a) |
| Badge | Basic | Refined with hover |

## Need Help?

Issues after upgrading? Check:
1. Browser console for JavaScript errors
2. Network tab for failed API calls
3. Verify backend is live: https://garage-wl13.onrender.com/health
4. Confirm production structure matches (see `tools/inspect-production.js`)
