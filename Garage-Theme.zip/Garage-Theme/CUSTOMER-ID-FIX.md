# Customer ID Fix - Garage Not Saving

## Problem
Garage was showing "Customer not logged in" error even when logged in, preventing saves.

## Root Cause
Mismatch between what the theme was providing and what the JavaScript expected:

- **Theme provided:** `window.Shopify.customer.id`
- **JavaScript expected:** `window.ShopifyGarage.customerId`

## Solution
Updated `layout/theme.liquid` to provide customer ID in both formats.

## Change Made

**File:** `layout/theme.liquid` (Lines 612-620)

**Added:**
```liquid
window.ShopifyGarage = window.ShopifyGarage || {};
window.ShopifyGarage.customerId = {{ customer.id | json }};
```

Now the script sets both:
- `window.Shopify.customer.id` (for filter integration)
- `window.ShopifyGarage.customerId` (for garage-v2.js)

## What This Fixes

1. ✅ Customer detection works when logged in
2. ✅ Vehicles save to backend
3. ✅ Auto-save functionality works
4. ✅ Badge updates with correct count
5. ✅ "My Garage" section populates
6. ✅ Vehicles persist after page reload

## Testing

After uploading updated theme:

1. **Log in as a customer**
2. **Open browser console** (F12 → Console)
3. **Type:** `window.ShopifyGarage.customerId`
4. **Should see:** A number (your customer ID)
5. **Click garage icon, add vehicle**
6. **Console should show:** "Garage saved successfully"
7. **Reload page**
8. **Badge should show:** Vehicle count
9. **Open modal**
10. **Should see:** Vehicle(s) in "My Garage" section at top

## Complete File List

All files needed for working garage:

**Layout:**
- ✅ `layout/theme.liquid` - Loads CSS/JS, customer ID, modal

**Sections:**
- ✅ `sections/header.liquid` - Garage icon with badge

**Assets:**
- ✅ `assets/garage.css` - All styling
- ✅ `assets/garage-v2.js` - Auto-save logic
- ✅ `assets/garage-filter-integration.js` - Collection filters

**Snippets:**
- ✅ `snippets/customer-garage-modal-v2.liquid` - Modal HTML
- ✅ `snippets/icon-garage.liquid` - Garage icon SVG

Everything should now work end-to-end!
