# Garage Filter Auto-Selection Setup

## What's Been Done

I've integrated the garage filter auto-selection feature directly into your Garage-Theme repository. Here's what's been added:

### 1. Files Added

- **`assets/garage-filter-integration.js`**
  - JavaScript that automatically applies collection filters based on customer's garage vehicles
  - Pre-configured with your production backend URL: `https://garage-wl13.onrender.com`
  - DEBUG mode disabled for production

### 2. Files Modified

- **`layout/theme.liquid`** (lines 607-621)
  - Added customer ID exposure to JavaScript (lines 612-618)
  - Added filter integration script loading on collection pages (lines 620-623)

## How It Works

When a logged-in customer with vehicles in their garage visits `/collections/all`:

1. Script detects they're on a collection page
2. Fetches their garage vehicles from backend
3. Automatically selects filters (Make, Year, Model) based on their **first vehicle**
4. Products are filtered to match their vehicle

Example: If customer has a 1946 Dodge D24 in their garage:
- Make filter → "Dodge"
- Year filter → "1946"
- Model filter → "D24" (if available)

## What You Need to Configure

### Filter Selectors

The script needs to know which HTML elements are your theme's filters. Currently it's set to generic selectors that might not match your theme.

**To find your theme's filter selectors:**

1. Go to https://www.robertsmotorparts.com/collections/all
2. Open browser DevTools (F12)
3. Right-click on a Make filter option → Inspect
4. Look at the `<input>` or `<select>` element
5. Note the `name` attribute

**Example:**
```html
<input type="checkbox" name="filter.v.option.make" value="Dodge">
```
The selector would be: `input[name="filter.v.option.make"]`

### Update the Selectors

Edit `assets/garage-filter-integration.js` lines 22-32:

```javascript
FILTER_SELECTORS: {
  // Replace these with your actual filter selectors
  make: 'input[name="YOUR_ACTUAL_MAKE_FILTER_NAME"]',
  year: 'input[name="YOUR_ACTUAL_YEAR_FILTER_NAME"]',
  model: 'input[name="YOUR_ACTUAL_MODEL_FILTER_NAME"]',

  // If using dropdowns instead of checkboxes:
  makeSelect: 'select[name="YOUR_DROPDOWN_NAME"]',

  // The form that contains the filters
  filterForm: 'form#YourFilterFormID'
}
```

## Testing

### Enable Debug Mode for Testing

Temporarily set `DEBUG: true` in `garage-filter-integration.js` line 34:

```javascript
DEBUG: true  // Change to true for testing
```

This will show console messages:
- `[Garage Filter] Customer has X vehicle(s) in garage`
- `[Garage Filter] Applying filters: { make, year, model }`
- `[Garage Filter] Selected filter: ...`

### Test Steps

1. Create a test customer account
2. Add a vehicle to their garage (use the test page at `frontend-test/index-v2.html`)
3. Log in as that customer on your Shopify store
4. Visit `/collections/all`
5. Open DevTools → Console
6. Check if filters auto-select

### If Filters Don't Apply

Check console for errors:
- **"Not on a collection page"** → Update `APPLY_ON_PAGES` array
- **"Customer not logged in"** → Make sure `window.Shopify.customer` exists
- **"No vehicles in garage"** → Customer needs vehicles saved
- **No filter selection messages** → Selectors need updating

## Deployment

Once you've configured the selectors:

1. **Upload theme to Shopify:**
   - Zip the Garage-Theme folder
   - Go to Shopify Admin → Online Store → Themes
   - Upload as a new theme or update existing

2. **Test on live site:**
   - Use a test customer account with garage vehicles
   - Visit collection page and verify auto-filtering

3. **Disable debug mode:**
   - Set `DEBUG: false` in `garage-filter-integration.js`
   - Re-upload theme

## Customization Options

### Apply Only to Specific Collections

Edit line 19 in `garage-filter-integration.js`:

```javascript
APPLY_ON_PAGES: ['/collections/all', '/collections/parts'], // Add specific collections
```

### Use Different Default Vehicle

Currently uses **first vehicle** in garage. To change this, you'd need to:
- Update backend endpoint to accept a vehicle preference
- Store customer's preferred default vehicle
- Pass that preference when fetching filters

### Apply Multiple Vehicles (OR Logic)

Currently applies filters for one vehicle. To show products for ALL vehicles in garage:
- Backend would return combined filters (all makes, all years, all models)
- Frontend would select all matching filters

## Support

If filters still don't apply after configuration:

1. Check browser console for `[Garage Filter]` messages (with DEBUG: true)
2. Verify backend is responding: `https://garage-wl13.onrender.com/health`
3. Test the filters endpoint directly:
   ```
   https://garage-wl13.onrender.com/apps/customer/vehicles/filters?customerId=gid://shopify/Customer/YOUR_ID
   ```

## Files Reference

- **Integration script:** `assets/garage-filter-integration.js`
- **Theme layout:** `layout/theme.liquid`
- **Backend endpoint:** `GET /apps/customer/vehicles/filters`
- **Detailed guide:** `frontend-shopify/FILTER-INTEGRATION-GUIDE.md`
