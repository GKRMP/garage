# Garage V2 Upgrade - Changes Applied

The Garage-Theme has been updated to use the new auto-save garage implementation (V2).

## Files Changed

### 1. layout/theme.liquid

**Line 649-650:** Updated modal rendering
```liquid
# OLD:
{%- render 'garage-view-modal' -%}
{%- render 'customer-garage-modal' -%}

# NEW:
{%- render 'customer-garage-modal-v2' -%}
```

**Line 771:** Updated JavaScript file
```liquid
# OLD:
<script src="{{ 'garage.js' | asset_url }}" defer="defer"></script>

# NEW:
<script src="{{ 'garage-v2.js' | asset_url }}" defer="defer"></script>
```

### 2. sections/header.liquid

**Line 407-419:** Updated garage button
```liquid
# OLD:
<button ... onclick="handleGarageClick()" ...>
  {%- render 'icon-garage' -%}
  ... Liquid-based badge ...
</button>

# NEW:
<button ... data-garage-icon ...>
  {%- render 'icon-garage' -%}
  <div ... data-garage-badge>0</div>
</button>
```

Changes:
- Removed `onclick="handleGarageClick()"`
- Added `data-garage-icon` attribute
- Badge now updated by JavaScript (data-garage-badge)

### 3. assets/garage.css

**Line 1-9:** Added badge visibility rules
```css
/* Garage Badge - Updated by JavaScript */
[data-garage-badge] {
  display: none !important;
}

[data-garage-badge].active {
  display: flex !important;
}
```

## Files Already in Place

These files were created earlier and are ready to use:

✅ `assets/garage-v2.js` - Modern auto-save implementation
✅ `snippets/customer-garage-modal-v2.liquid` - Modern modal UI
✅ `assets/garage-filter-integration.js` - Collection filter auto-selection

## What's New in V2

### User Experience
- ✅ No manual save button - saves automatically after 1 second
- ✅ "My Garage" displayed as chips at top of modal
- ✅ Simple search box for all vehicles
- ✅ Click vehicle or checkbox to add/remove
- ✅ Visual feedback with "Saving..." / "✓ Saved" indicator

### Technical
- ✅ Debounced auto-save (prevents excessive API calls)
- ✅ Vehicle caching (1 hour) for faster load times
- ✅ Cleaner, more maintainable code (400 vs 700 lines)
- ✅ Production backend pre-configured

## Testing

After uploading the theme to Shopify:

1. **Log in as a customer**
2. **Click the garage icon** in header
3. **Modal should show:**
   - Search box at top
   - List of all vehicles
   - Empty state message initially

4. **Click a vehicle** to add it
   - Should see "Saving..." then "✓ Saved"
   - Vehicle appears as chip at top
   - Badge shows count (1)

5. **Click X on chip** to remove
   - Should auto-save again
   - Vehicle removed from top
   - Badge updates count

6. **Reload page**
   - Badge should show correct count
   - Opening modal should show saved vehicles

7. **Test collection filter integration**
   - Visit /collections/all
   - If customer has vehicles, filters should auto-select
   - Check browser console for "[Garage Filter]" messages (if DEBUG: true)

## Rollback (If Needed)

If V2 has issues, revert these three files:

1. **layout/theme.liquid** (2 changes)
   - Line 649: Change back to `garage-view-modal` and `customer-garage-modal`
   - Line 771: Change back to `garage.js`

2. **sections/header.liquid** (1 change)
   - Line 407: Change back to `onclick="handleGarageClick()"`
   - Remove `data-garage-icon` attribute
   - Restore Liquid-based badge logic

3. **Clear browser cache** and test

## Notes

- Old files (`garage.js`, `customer-garage-modal.liquid`) are still in the theme but not being used
- You can delete them once V2 is confirmed working
- Backend URL is already configured: https://garage-wl13.onrender.com
- Customer ID is already exposed via earlier filter integration changes

## Next Steps

1. Upload theme to Shopify
2. Test with a customer account
3. Verify auto-save works
4. Check badge updates correctly
5. Test collection filter auto-selection
